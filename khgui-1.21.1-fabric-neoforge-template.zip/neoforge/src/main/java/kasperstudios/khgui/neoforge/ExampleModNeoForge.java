package kasperstudios.khgui.neoforge;

import net.neoforged.fml.common.Mod;

import kasperstudios.khgui.ExampleMod;

@Mod(ExampleMod.MOD_ID)
public final class ExampleModNeoForge {
    public ExampleModNeoForge() {
        // Run our common setup.
        ExampleMod.init();
    }
}
