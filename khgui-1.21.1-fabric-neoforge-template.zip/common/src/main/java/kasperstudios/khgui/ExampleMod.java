package kasperstudios.khgui;

public final class ExampleMod {
    public static final String MOD_ID = "khgui";

    public static void init() {
        // Write common init code here.
    }
}
